<style>
   input[type = "text"],select{
   color: blue; font-weight: bold;
   }
   
</style>

<div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('label_payment'); ?></h5>
            <button type="button" class="close" onclick = "$('#another_popup').modal('hide');">
              <span aria-hidden="true">×</span>
          </button>
         </div>
         
      <?php 
         $form_data = array('class' => 'm-form m-form--fit m-form--label-align-right','id' => 'p_m_form_1','enctype'=>'multipart/form-data'); 
         echo form_open('company/invoices/pay_invoice/',$form_data); 
         ?> 

      <div class="modal-body">
        <input type = "hidden" name = "p_invoice_id" id = "p_invoice_id" value = "<?=$result['id']?>">
         <div class="m-scrollable" data-scrollbar-shown="true" data-scrollable="true" data-max-height="">
            <div class="row">
               <div class="col-lg-4">
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_date')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" name="p_due_date" id="p_due_date" value = "<?=date('m-d-Y',strtotime($result['duedate']))?>" disabled>
                     </div>
                  </div>
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('field_exchange_rate')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" name="p_exchange_rate" id="p_exchange_rate" placeholder = "<?=$this->lang->line('field_exchange_rate')?>" disabled>
                     </div>
                  </div>
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_total_dollor')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" id = "p_total_dollor" name = "p_total_dollor" placeholder = "<?=$this->lang->line('label_total_dollor')?>" value = "<?=$result['balance']?>" disabled>
                     </div>
                  </div>


               </div>
               <div class="col-lg-4">
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_personal')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" name="p_driver" id="p_driver" value = "<?=$result['driver_name']?>" disabled>
                     </div>
                  </div>
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_reffeence')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" name="p_reffeence" id="p_reffeence" placeholder = "<?=$this->lang->line('label_reffeence')?>" >
                     </div>
                  </div>
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_total_peso')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                     
                        <input type="text" class="form-control m-input" id = "p_total_peso" name = "p_total_peso" placeholder = "<?=$this->lang->line('label_total_peso')?>" disabled>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_currency')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <select class  = "form-control m-input" id = "p_currency" name = "p_currency" style = "height:30px;">
                           <option value = "dollor"><?=$this->lang->line('label_dollor')?></option>
                           1
                           <option value = "peso"><?=$this->lang->line('label_peso')?></option>
                        </select>
                     </div>
                  </div>
                  <div class="row mb-3">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_amount')?>*
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <input type="text" class="form-control m-input" name="p_amount" id="p_amount" placeholder = "<?=$this->lang->line('label_amount')?>" value = "<?=$result['balance']?>">
                     </div>
                  </div>


                  <div class="row mb-2">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     <?=$this->lang->line('label_payment_type')?>
                     </label>
                     <div class="col-md-6 col-lg-7">
                        <select class="form-control m-input" id = "p_payment_type" name = "p_payment_type" style = "height:30px;">
                          <option value = "card"><?php echo $this->lang->line('label_card'); ?></option>
                          <option value = "cash"><?php echo $this->lang->line('label_cash'); ?></option>
                        </select>
                     </div>
                  </div>

                  <div class="row mb-1">
                     <label class="form_label col-md-6 col-lg-5 text-right">
                     </label>
                     <div class="col-md-6 col-lg-7 text-right">
                        <a href="javascript:;" class="btn btn-info m-btn m-btn--custom m-btn--icon m-btn--air m-btn--pill" id = "p_submit">
                        <?=$this->lang->line('label_apply')?>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <?php echo form_close(); ?>
         </div>
      </div>
   
   
<!--begin::Page Snippets -->
<script type="text/javascript">
$(document).on('click','#p_submit',function(){
   var data = $("#p_m_form_1").serialize();
   var url = $("#p_m_form_1").attr('action');

   ajaxCall(url,data,function(response){
   

    


    if(response.status == ERROR_CODE){

        getMessage(response.status,response.message);
    }else{

        swal({
    title: "Wow!",
    type: response.status,
    text: response.message
}).then(function() {
    
    $("#p_payment_form").html('');

    $("#another_popup").modal('hide');
});

       // getMessage(response.status,response.message,SITE_URL+'company/invoices');
    }
    

   });

   return false;
})

$(document).on('change','#p_currency',function(){

    
    
    if($(this).val() == 'peso'){

        $("#p_exchange_rate").val('').prop('disabled',false);
        
    }else{

        $("#p_exchange_rate,#p_total_peso").val('').prop('disabled',true);
    }
})
$(document).on('keypress keyup','#p_exchange_rate,#p_amount',function(){
    var val  = $("#p_exchange_rate").val();
    var p_amount  = $('#p_amount').val();
    console.log(val+' '+p_amount);
    if(isNaN(val) == false && isNaN(p_amount) == false){
        
    var newAmount = val*p_amount;
    
    $("#p_total_peso").val(newAmount);


    }
});
</script>