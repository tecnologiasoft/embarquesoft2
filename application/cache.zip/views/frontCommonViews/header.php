<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <link rel="shortcut icon" href="<?=IMAGES.'favicon.png'?>">
  <link rel="stylesheet" href="<?php echo JS_FILE.'jquery.min.js'?>">
  <link rel="stylesheet" href="<?php echo CSS_FILE.'bootstrap.min.css'?>">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="<?php echo CSS_FILE.'bootstrap.min.css'?>">
  
  
  
  <link rel="stylesheet" href="<?php echo CSS_FILE.'login.css' ?>">
  <style>
  </style>
</head>
<body>


